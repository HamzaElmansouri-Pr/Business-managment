<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Tests\TestCase;

class CustomerApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_admin_can_list_customers(): void
    {
        Role::create(['name' => 'admin']);
        $admin = User::factory()->create();
        $admin->assignRole('admin');

        Customer::factory(3)->create();

        $this->actingAs($admin)
            ->getJson('/api/v1/customers')
            ->assertOk()
            ->assertJsonCount(3, 'data');
    }

    public function test_admin_can_create_customer(): void
    {
        Role::create(['name' => 'admin']);
        $admin = User::factory()->create();
        $admin->assignRole('admin');

        $payload = [
            'name' => 'Amina El Fassi',
            'email' => 'amina@example.com',
        ];

        $this->actingAs($admin)
            ->postJson('/api/v1/customers', $payload)
            ->assertCreated()
            ->assertJsonPath('data.name', 'Amina El Fassi');

        $this->assertDatabaseHas('customers', ['email' => 'amina@example.com']);
    }

    public function test_staff_cannot_create_customer(): void
    {
        Role::create(['name' => 'staff']);
        $staff = User::factory()->create();
        $staff->assignRole('staff');

        $this->actingAs($staff)
            ->postJson('/api/v1/customers', ['name' => 'X', 'email' => 'x@example.com'])
            ->assertForbidden();
    }
}
