# Opsly backend — setup

These files are the app-specific code for the Business Operations Management
Platform. They are NOT a full Laravel install (no composer.json, vendor/, etc.)
— you drop them into a fresh Laravel project.

## 1. Create the project (run locally, where you have full internet access)

```bash
composer create-project laravel/laravel opsly-backend
cd opsly-backend
composer require laravel/sanctum spatie/laravel-permission
php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
php artisan install:api   # publishes Sanctum config + api.php
```

## 2. Copy these files in, matching the folder structure

- `app/Models/*` → `app/Models/`
- `app/Http/Controllers/Api/*` → `app/Http/Controllers/Api/`
- `app/Http/Requests/*` → `app/Http/Requests/`
- `app/Http/Resources/*` → `app/Http/Resources/`
- `app/Policies/*` → `app/Policies/`
- `database/migrations/*` → `database/migrations/`
- `database/factories/*` → `database/factories/`
- `database/seeders/*` → `database/seeders/` (replace the default `DatabaseSeeder.php`)
- `routes/api.php` → `routes/api.php` (merge with the one `install:api` created)
- `tests/Feature/CustomerApiTest.php` → `tests/Feature/`

## 3. Register the policy

In `app/Providers/AppServiceProvider.php` (or a dedicated `AuthServiceProvider`
if you prefer), register:

```php
Gate::policy(\App\Models\Customer::class, \App\Policies\CustomerPolicy::class);
```

## 4. Configure `.env`

Set your DB connection (SQLite is fine for a quick local demo:
`touch database/database.sqlite` and set `DB_CONNECTION=sqlite`).

## 5. Migrate and seed

```bash
php artisan migrate --seed
```

This creates an `admin@opsly.test` and `manager@opsly.test` user, 25 fake
customers, 15 products/services, and 40 orders with realistic line items —
so the dashboard has real-looking numbers immediately, not empty tables.

## 6. Run it

```bash
php artisan serve
php artisan test   # runs CustomerApiTest
```

## What's next (Products + Orders controllers)

`CustomerController` is the full reference pattern — request validation,
policy-based authorization, pagination, search, API resource shaping.
`ProductController` and `OrderController` follow the exact same shape; say
the word and I'll write those next (Orders also needs the nested order-items
create logic + total recalculation, which `Order::recalculateTotal()` already
supports).
