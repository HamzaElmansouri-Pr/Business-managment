<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    public function definition(): array
    {
        $type = $this->faker->randomElement(['product', 'service']);

        return [
            'name' => ucfirst($this->faker->words(3, true)),
            'sku' => strtoupper($this->faker->unique()->bothify('SKU-####')),
            'description' => $this->faker->sentence(),
            'type' => $type,
            'price' => $this->faker->randomFloat(2, 10, 500),
            'stock' => $type === 'product' ? $this->faker->numberBetween(0, 100) : null,
            'is_active' => true,
        ];
    }
}
