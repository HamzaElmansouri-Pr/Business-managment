<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;

class DemoDataSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::factory()->create([
            'name' => 'Admin User',
            'email' => 'admin@opsly.test',
        ]);
        $admin->assignRole('admin');

        $manager = User::factory()->create([
            'name' => 'Manager User',
            'email' => 'manager@opsly.test',
        ]);
        $manager->assignRole('manager');

        $customers = Customer::factory(25)->create();
        $products = Product::factory(15)->create();

        Order::factory(40)
            ->recycle($customers)
            ->create()
            ->each(function (Order $order) use ($products) {
                $items = $products->random(rand(1, 3));
                foreach ($items as $product) {
                    OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $product->id,
                        'quantity' => rand(1, 4),
                        'unit_price' => $product->price,
                    ]);
                }
                $order->recalculateTotal();
            });
    }
}
