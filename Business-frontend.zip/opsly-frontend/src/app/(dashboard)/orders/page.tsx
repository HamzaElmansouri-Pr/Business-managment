import { Plus } from "lucide-react";
import { StatusPill } from "@/components/StatusPill";
import { mockOrders } from "@/lib/mock-data";

const currency = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });

export default function OrdersPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-base font-medium">Orders</h1>
        <button className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-[var(--radius)] border border-[var(--border-strong)] hover:bg-[var(--surface-1)] transition-colors">
          <Plus size={14} />
          New order
        </button>
      </div>

      <div className="bg-[var(--surface-1)] rounded-xl border border-[var(--border)] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--border)] text-[var(--text-secondary)]">
              <th className="text-left font-normal px-4 py-2.5">Order</th>
              <th className="text-left font-normal px-4 py-2.5">Customer</th>
              <th className="text-left font-normal px-4 py-2.5">Date</th>
              <th className="text-left font-normal px-4 py-2.5">Status</th>
              <th className="text-right font-normal px-4 py-2.5">Total</th>
            </tr>
          </thead>
          <tbody>
            {mockOrders.map((order) => (
              <tr key={order.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-2.5">#{order.id}</td>
                <td className="px-4 py-2.5">{order.customer.name}</td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)]">{order.created_at}</td>
                <td className="px-4 py-2.5">
                  <StatusPill status={order.status} />
                </td>
                <td className="px-4 py-2.5 text-right">{currency(order.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
