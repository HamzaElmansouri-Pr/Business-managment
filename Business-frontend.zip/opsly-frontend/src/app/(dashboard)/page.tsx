import { Plus } from "lucide-react";
import { MetricCard } from "@/components/MetricCard";
import { StatusPill } from "@/components/StatusPill";
import { mockMetrics, mockOrders } from "@/lib/mock-data";

const currency = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

export default function DashboardPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-base font-medium">Overview</h1>
        <button className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-[var(--radius)] border border-[var(--border-strong)] hover:bg-[var(--surface-1)] transition-colors">
          <Plus size={14} />
          New order
        </button>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-6">
        <MetricCard label="Revenue" value={currency(mockMetrics.revenue)} />
        <MetricCard label="Orders" value={mockMetrics.orders.toLocaleString("en-US")} />
        <MetricCard label="Customers" value={mockMetrics.customers.toLocaleString("en-US")} />
        <MetricCard label="Avg. order" value={currency(mockMetrics.avgOrder)} />
      </div>

      <div className="bg-[var(--surface-1)] rounded-xl border border-[var(--border)] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--border)] text-[var(--text-secondary)]">
              <th className="text-left font-normal px-4 py-2.5">Order</th>
              <th className="text-left font-normal px-4 py-2.5">Customer</th>
              <th className="text-left font-normal px-4 py-2.5">Status</th>
              <th className="text-right font-normal px-4 py-2.5">Amount</th>
            </tr>
          </thead>
          <tbody>
            {mockOrders.map((order) => (
              <tr key={order.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-2.5">#{order.id}</td>
                <td className="px-4 py-2.5">{order.customer.name}</td>
                <td className="px-4 py-2.5">
                  <StatusPill status={order.status} />
                </td>
                <td className="px-4 py-2.5 text-right">{currency(order.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
