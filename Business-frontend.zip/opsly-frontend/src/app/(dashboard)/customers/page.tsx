import { Plus, Search } from "lucide-react";
import { mockCustomers } from "@/lib/mock-data";

export default function CustomersPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-base font-medium">Customers</h1>
        <button className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-[var(--radius)] border border-[var(--border-strong)] hover:bg-[var(--surface-1)] transition-colors">
          <Plus size={14} />
          New customer
        </button>
      </div>

      <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface-1)] max-w-xs">
        <Search size={14} className="text-[var(--text-muted)]" />
        <input
          placeholder="Search customers"
          className="bg-transparent text-sm outline-none placeholder:text-[var(--text-muted)] w-full"
        />
      </div>

      <div className="bg-[var(--surface-1)] rounded-xl border border-[var(--border)] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--border)] text-[var(--text-secondary)]">
              <th className="text-left font-normal px-4 py-2.5">Name</th>
              <th className="text-left font-normal px-4 py-2.5">Email</th>
              <th className="text-left font-normal px-4 py-2.5">Location</th>
              <th className="text-right font-normal px-4 py-2.5">Orders</th>
            </tr>
          </thead>
          <tbody>
            {mockCustomers.map((customer) => (
              <tr key={customer.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-2.5">{customer.name}</td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)]">{customer.email}</td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)]">{customer.address}</td>
                <td className="px-4 py-2.5 text-right">{customer.orders_count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
