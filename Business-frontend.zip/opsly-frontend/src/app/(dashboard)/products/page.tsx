import { Plus } from "lucide-react";
import { mockProducts } from "@/lib/mock-data";

const currency = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });

export default function ProductsPage() {
  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-base font-medium">Products & services</h1>
        <button className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-[var(--radius)] border border-[var(--border-strong)] hover:bg-[var(--surface-1)] transition-colors">
          <Plus size={14} />
          New product
        </button>
      </div>

      <div className="bg-[var(--surface-1)] rounded-xl border border-[var(--border)] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--border)] text-[var(--text-secondary)]">
              <th className="text-left font-normal px-4 py-2.5">Name</th>
              <th className="text-left font-normal px-4 py-2.5">SKU</th>
              <th className="text-left font-normal px-4 py-2.5">Type</th>
              <th className="text-left font-normal px-4 py-2.5">Stock</th>
              <th className="text-right font-normal px-4 py-2.5">Price</th>
            </tr>
          </thead>
          <tbody>
            {mockProducts.map((product) => (
              <tr key={product.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-2.5">
                  {product.name}
                  {!product.is_active && (
                    <span className="ml-2 text-xs text-[var(--text-muted)]">Inactive</span>
                  )}
                </td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)]">{product.sku}</td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)] capitalize">{product.type}</td>
                <td className="px-4 py-2.5 text-[var(--text-secondary)]">{product.stock ?? "—"}</td>
                <td className="px-4 py-2.5 text-right">{currency(product.price)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
